import os

SCORES_FILE_NAME = "Scores.txt"
BAD_RETURN_CODE = 11


def screen_cleaner():
    os.system('cls')
